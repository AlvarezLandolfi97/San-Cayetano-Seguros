"""Migrations for common app."""
