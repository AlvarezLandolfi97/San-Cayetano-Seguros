# tests package marker for pytest/django discovery
