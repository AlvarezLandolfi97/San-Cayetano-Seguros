from django.contrib import admin
from .models import Payment, Receipt

admin.site.register(Payment)
admin.site.register(Receipt)
