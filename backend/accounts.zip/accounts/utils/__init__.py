"""
Helper utilities for accounts.
"""
