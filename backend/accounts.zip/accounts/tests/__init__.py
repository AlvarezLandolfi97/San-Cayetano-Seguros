# tests package marker for Django discovery
