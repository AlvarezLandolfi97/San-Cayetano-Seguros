from django.contrib import admin
from .models import Inspection
admin.site.register(Inspection)
