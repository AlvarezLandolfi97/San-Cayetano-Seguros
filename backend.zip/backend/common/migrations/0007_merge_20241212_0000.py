from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("common", "0006_appsettings_price_update_every_months"),
        ("common", "0005_appsettings_due_days"),
    ]

    operations = []
