# Marker file for Django management commands package
